# MoParticles

A Minecraft plugin that parses **MoLang** (Bedrock particle language),
bakes the result into a Java-edition compatible animation, generates a
resource pack with the necessary textures, and plays the animation
client-side.

* **Name:** MoParticles
* **Author:** RedSnicker
* **Company:** Chest Solutions
* **Namespace:** `com.csl.moparticles`
* **Targets:** Paper **1.21.4 – 26.1.2**.
  Compiled against `paper-api 1.21.11-R0.1-SNAPSHOT`.  Uses stable
  Paper API surface that exists in every Paper build from
  1.20.6 up to 26.2.

## Build

```
./gradlew shadowJar
```

The runnable jar is built at `build/libs/MoParticles-1.0-all.jar`.

## Two render modes

The plugin has two render backends.  Switch with
`/moparticles mode <native|packet>`.

### `native` (default — works without packetevents)

* Uses Paper's native API: `World.spawn(ItemDisplay.class)` for
  visible floating items, and `Player.spawnParticle(Particle.DUST, ...)`
  for coloured dust.
* The server tracks every entity, so cleanup is automatic.
* No packetevents dependency required.
* No risk of dropped packets.

### `packet` (requires packetevents 2.12.x)

* Uses `WrapperPlayServerSpawnEntity` + `WrapperPlayServerEntityMetadata`
  to send client-side display entities the server does not know about.
* Useful if you want to test raw packet work.

## Commands

```
/moparticles list
/moparticles play <effect> <location> [radius]
/moparticles playhere <effect> [radius]
/moparticles playherep <effect> [radius]   (private - only visible to you)
/moparticles stop <id>
/moparticles stopall
/moparticles reload
/moparticles info <effect>
/moparticles debug                          (toggle marker entities)
/moparticles mode [native|packet]           (show or set render mode)
/moparticles whereami
```

## Debug mode

`/moparticles debug` toggles a debug flag.  When on, every baked
particle position is also marked with a glowing invisible
armor stand so you can see *exactly* where the animation is trying
to render.  Use this to confirm positions are right even when the
display entities are too small to see.

## Example particles

Bundled effects (in `src/main/resources/particles/`):

* `moparticles:example_flame`        – a small upward flame
* `moparticles:example_sparkle`      – a one-shot burst of sparkles
* `moparticles:example_hearts`       – floating hearts
* `moparticles:example_grand_ritual` – a looping multi-coloured swirl
* `moparticles:grand_ritual`         – the "snowstorm compatible" version

Add your own by dropping more `.json` files into
`plugins/MoParticles/particles/` and running `/moparticles reload`.

## Programmatic use

```java
import com.csl.moparticles.api.MoParticleAPI;
MoParticleAPI api = MoParticleAPI.get();
UUID id = api.play("moparticles:example_flame", location, 32);
api.stop(id);
```
